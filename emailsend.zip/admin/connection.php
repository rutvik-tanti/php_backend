<?php
    $serverHost = "localhost";
    $user = "root";
    $password = "";
    $database = "newdb";

    $connectNow = new mysqli($serverHost,$user,$password,$database);
?>