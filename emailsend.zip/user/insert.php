<?php
    include 'connection.php';

    $uname = $_POST['uname'];
    $uemail = $_POST['uemail'];
    $upass = $_POST['upass'];
    $umono = $_POST['umono'];
    $imageName = $_POST['image_name'];
    $imageData = $_POST['image_data'];

	if($imageName!=""){
		$path = "img/$imageName";
		file_put_contents($path,base64_decode($imageData));
	}else{
		$path = "null";
	}

    $sqlQuery = "INSERT INTO user_pro SET uname = '$uname',uemail = '$uemail',upass= '$upass',umono = '$umono',uimage = '$path'";

    $resultOfQuery = $connectNow -> query($sqlQuery);

    if($resultOfQuery) {
        echo json_encode(array("success" => true));
    } else {
        echo json_encode(array("success" => false));
    }

?>
