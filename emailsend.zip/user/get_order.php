<?php
    include 'connection.php';

    $uid = "".$_POST['uid'];

    $sqlQuery = "SELECT placeorder.*, address.*, payment.*
				FROM placeorder
				INNER JOIN address ON address.id = placeorder.u_address
				LEFT JOIN payment ON payment.merchantTransactionId = placeorder.o_id
				WHERE placeorder.uid = '$uid'";
				
	if(isset($_POST['oid'])){
		$sqlQuery .= " and o_id = ".$_POST['oid'];
	}
	
	$sqlQuery .= " ORDER BY ounique_id DESC";

    $result = $connectNow->query($sqlQuery);

    if ($result) {
        $data = array();

        while ($row = $result->fetch_assoc()) {
            $data[] = $row;
        }

        echo json_encode($data);
    } else {
        // Handle query execution error
        echo json_encode(array("success" => false, "error" => $connectNow->error));
    }
?>
