<?php

include 'connection.php';
$uid = "".$_POST['uid'];
$sqlQuery = "DELETE FROM cart_table WHERE current_user_id = '$uid'";

$resultOfQuery = $connectNow->query($sqlQuery);

if ($resultOfQuery) {
    echo json_encode(array("success" => true));
} else {
    echo json_encode(array("success" => false));
}

?>
