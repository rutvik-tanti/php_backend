<?php
    include 'connection.php';
    
    $name = "".$_POST['name'];
    $mono = "".$_POST['mono'];
    $pincode = "".$_POST['pincode'];
    $state = "".$_POST['state'];
    $city = "".$_POST['city'];
    $street = "".$_POST['street'];
    $landmark = "".$_POST['landmark'];
    $uid = "".$_POST['uid'];

    $sqlQuery = "INSERT INTO address SET name = '$name',mono = '$mono', pincode = '$pincode', state = '$state', city = '$city', street = '$street', landmark = '$landmark', uid = '$uid'";

    $resuletOfQuery = $connectNow->query($sqlQuery);

    if($resuletOfQuery) {
        echo json_encode(array("success"=>true));
    } else {
        echo json_encode(array("success"=>false));
    }
?>